
package Interfaces;

public interface Explorable {
    void explorar();
}
