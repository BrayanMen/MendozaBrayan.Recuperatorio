package Enums;

public enum Mision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO,
}
