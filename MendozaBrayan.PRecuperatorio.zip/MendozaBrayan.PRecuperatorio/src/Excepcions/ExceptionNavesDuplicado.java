package Excepcions;

public class ExceptionNavesDuplicado extends RuntimeException {

    public ExceptionNavesDuplicado(String mensaje) {
        super(mensaje);
    }
}
